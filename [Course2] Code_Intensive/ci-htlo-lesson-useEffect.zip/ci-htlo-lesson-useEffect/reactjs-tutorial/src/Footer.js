function Footer() {
  return <footer>Dday la Footer ne</footer>;
}

export default Footer;
