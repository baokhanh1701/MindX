function ProductItem() {
  return <div>Item 1</div>;
}

export default ProductItem;
