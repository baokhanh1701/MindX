function Content() {
  return <main>Dday la Noi DUng</main>;
}

export default Content;
