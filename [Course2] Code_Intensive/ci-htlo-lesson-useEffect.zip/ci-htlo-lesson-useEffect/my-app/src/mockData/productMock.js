const projectData = [
  {
    id: 1,
    thumNe:
      "https://blogapi.uber.com/wp-content/uploads/2020/12/pasted-image-0-14.png",
    titleNe: "Khoa hoc ReactJS",
  },
  {
    id: 2,
    thumNe:
      "https://blogapi.uber.com/wp-content/uploads/2020/12/pasted-image-0-14.png",
    titleNe: "Khoa hoc Kafka",
  },
  {
    id: 3,
    thumNe:
      "https://blogapi.uber.com/wp-content/uploads/2020/12/pasted-image-0-14.png",
    titleNe: "Khoa hoc Golang",
  },
  {
    id: 4,
    thumNe:
      "https://blogapi.uber.com/wp-content/uploads/2020/12/pasted-image-0-14.png",
    titleNe: "Khoa hoc Blockchain",
  },
  {
    id: 5,
    thumNe:
      "https://blogapi.uber.com/wp-content/uploads/2020/12/pasted-image-0-14.png",
    titleNe: "Khoa hoc Rust for Solana",
  },
];

export default projectData;
