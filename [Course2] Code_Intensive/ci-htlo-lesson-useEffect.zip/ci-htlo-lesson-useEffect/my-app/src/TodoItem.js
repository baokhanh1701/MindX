const TodoItem = () => {
  return (
    <div className="todo-item">
      <span>Item 1</span>
      <button>X</button>
    </div>
  );
};

export default TodoItem;
