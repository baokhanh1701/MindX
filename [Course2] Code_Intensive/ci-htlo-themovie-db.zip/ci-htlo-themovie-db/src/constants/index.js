export const THEMOVIE_DB_API_KEY = "0a6d26d952bdd58d29ef7b7cb82a59db";
